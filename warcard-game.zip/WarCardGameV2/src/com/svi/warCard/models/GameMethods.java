package com.svi.warCard.models;

import java.util.ArrayList;
import java.util.*;

public class GameMethods {
	public static void giveCards(int numOfPlayers, List<Player> listPlayer, ArrayList<Card> deck) {
		int n = 0;
		do {
			if (n != numOfPlayers) {
				for (n = 0; n < numOfPlayers; n++) {
					listPlayer.get(n).getHands().add(deck.get(0));
					deck.remove(0);
				}
			} else if (n == numOfPlayers) {
				n = 0;
			}
		} while (!deck.isEmpty());
		// Reverse order to have the AceofDiamonds be the last card of Player 1
		
		System.out.println("INITIAL DECKS : ");
		for (Player player : listPlayer) {
			Collections.reverse(player.getHands());
			System.out.println(player.getPlayerName() + " : " + player.getHands());
		}
	}
	
	public static List<Card> getTopCards(List<Player> playerList) {
		List<Card> topCardList = new ArrayList<Card>();
		for (Player player : playerList) {
			topCardList.add(player.getHands().get(0));
			player.getHands().remove(0);
		}
		return topCardList;
	}
	public static void startGame(List<Player> listPlayer, int numOfPlayers) {
		List<Card> topCardList = new ArrayList<Card>();
		System.out.println("----------------------------------------------------");
		for (Player player : listPlayer) {
			System.out.println(player.getPlayerName() + " : " + player.getHands());
		}
		topCardList = (ArrayList<Card>) GameMethods.getTopCards(listPlayer);
		System.out.println("Table's Cards: " + topCardList);
		Card topCard = Collections.max(topCardList, Comparator.comparing(s -> s.getCardValue()));
		int tempindex = topCardList.indexOf(topCard);
		Collections.rotate(topCardList, topCardList.size() - topCardList.indexOf(topCard));
		listPlayer.get(tempindex).getHands().addAll(topCardList);
		System.out.println("The winning card is : " + topCard);
		topCardList.clear();
		listPlayer.removeIf(player -> listPlayer.getHands().isEmpty());
	}
}

