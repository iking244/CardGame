package com.svi.warCard.models;

import java.util.ArrayList;
import java.util.List;
public class Player {

	private List<Card> hands;
	private String playerName;

	public Player(String name){
		this.playerName = name;
		hands= new ArrayList<Card>();

	} 

	public String getPlayerName(){
		return playerName;
	}

	public List<Card> getHands(){
		return hands;
	}



}

