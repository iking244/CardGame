package com.svi.WarCard.main;
import java.util.*;
import com.svi.WarCard.models.*;

public class WarCard{

	public static void main(String[] args) {
		int numOfPlayers = 0;
		int numOfShuffles = 0;
		boolean continueLoop = true;

		System.out.println("Welcome to War Card Game!");

		// Initialize scanner
		Scanner scan = new Scanner(System.in);
		do {
			try {
				System.out.println("Please enter the number of players (2 or 4 only): ");
				numOfPlayers = scan.nextInt();
				if ((numOfPlayers == 2) || (numOfPlayers == 4)) {
					continueLoop = false;
				} else {
					System.out.println("2 or 4 players only. Try again.");

				}
			} catch (InputMismatchException e) {
				System.out.println("Try again. Please enter a valid number.");
				scan.nextLine();
			}
		} while (continueLoop);

		continueLoop = true; // set default value for next try catch

		do {
			try {
				System.out.println("Please enter the number of times the deck will be shuffled: ");
				numOfShuffles = scan.nextInt();
				if (numOfShuffles < 1) {
					System.out.println("Shuffle the deck at least once!");
				} else {
					continueLoop = false;
				}
			} catch (InputMismatchException e) {
				System.out.println("Please enter a number.");
				scan.nextLine();
			}
		} while (continueLoop);

		scan.close();

		ArrayList<Card> deck = GameMethods.generateDeck(); //Creates initial Deck
		
		ArrayList<Card> shuffledDeck = GameMethods.perfectShuffle(numOfShuffles, deck); // Shuffling of deck

		// Display shuffled deck
		System.out.println("\n\nShuffled deck:");
		for (Card card : shuffledDeck) {
			System.out.print(card.toString() + ",");
		}
		System.out.println('\n');

		List<Player> listPlayer = Player.addPlayer(numOfPlayers); // creates Player/s
		
		// deal Cards
		GameMethods.dealCards(numOfPlayers, listPlayer, shuffledDeck);
		
		// Start the game
		int round = 1;
		while (listPlayer.size() > 1) {
			System.out.println("\nround : " + round);
			GameMethods.startGame(listPlayer, numOfPlayers);
			System.out.println("**********************************************");
			round++;
		}
		System.out.println("Only 1 player left. The game ends."); // Game ends with 1 player left.
		System.out.println("\nThe winner is " + listPlayer.get(0).getPlayerName() + ". Total Round : " + (round - 1));
		for (Player player : listPlayer) {
			System.out.println("Winning Deck : " + player.getHands());
		}
	}

}
