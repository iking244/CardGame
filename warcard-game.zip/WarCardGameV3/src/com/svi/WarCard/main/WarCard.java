package com.svi.WarCard.main;


import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.svi.WarCard.models.Card;
import com.svi.WarCard.models.GameMethods;
import com.svi.WarCard.models.Player;

public class WarCard{


	public static void main(String[] args) throws IOException  {

		int numOfPlayers = 0;
		int numOfShuffles = 0;
		boolean continueLoop = true;
		{
			// Initialize scanner
			System.out.println("Welcome to War Card Game. \n*******************************************************************\n");
			Scanner scan = new Scanner(System.in);
			do {
				try {
					System.out.println("Please enter the number of players: ");
					numOfPlayers = scan.nextInt();
					if (numOfPlayers <= 1){
						System.err.println("Atleast 2 players are needed. Try again.");

					}else{
						continueLoop=false;
					}
				} catch (InputMismatchException e) {
					System.err.println("Please enter a valid number.");
					scan.nextLine();
				}
			} while (continueLoop);

			continueLoop = true; // set default value for next try catch

			do {
				try {
					System.out.println("Please enter the number of times the deck will be shuffled: ");
					numOfShuffles = scan.nextInt();
					if (numOfShuffles == 0) {
						numOfShuffles =8;
						continueLoop=false; // If number of shuffles is 0, generate the initial deck.

					} else {
						continueLoop = false;
					}
				} catch (InputMismatchException e) {
					System.err.println("Please enter a valid number.");
					scan.nextLine();
				}
			} while (continueLoop);
			scan.close();

			ArrayList<Card> deck = GameMethods.generateDeck(); //creates initial deck

			ArrayList<Card> shuffledDeck = GameMethods.perfectShuffle(numOfShuffles, deck); // Shuffling of deck

			// Display shuffled deck
			System.out.println("\n\nShuffled deck:");
			for (Card card : shuffledDeck) {
				System.out.print(card.toString() + ",");
			}
			System.out.println('\n');

			List<Player> listPlayer = Player.addPlayer(numOfPlayers); // creates Player/s

			// deal Cards
			GameMethods.dealCards(numOfPlayers, listPlayer, shuffledDeck);
			listPlayer.removeIf(player -> player.getHands().isEmpty());

			//Start the game
			int round = 1;
			while (listPlayer.size() > 1) {
				System.out.println("\nround : " + round);
				GameMethods.startGame(listPlayer, numOfPlayers);
				System.out.println("**********************************************");
				round++;
			}
			System.out.println("Only 1 player left. The game ends."); // Game ends with 1 player left.
			System.out.println("\nThe winner is " + listPlayer.get(0).getPlayerName() + ". Total Round : " + (round - 1));
			for (Player player : listPlayer) {
				System.out.println("Winning Deck : " + player.getHands());
			}
		}
	}
}


