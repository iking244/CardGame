package com.svi.WarCard.main;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.svi.WarCard.models.Card;
import com.svi.WarCard.models.Deck;
import com.svi.WarCard.models.GameMethods;
import com.svi.WarCard.models.Player;
import com.svi.WarCard.models.Rank;
import com.svi.WarCard.models.Suit;

public class WarCard extends GameMethods {

	public static void main(String[] args) {
		int numOfPlayers = 0;
		int numOfShuffles = 0;
		boolean continueLoop = true;

		System.out.println("Welcome to War Card Game!");

		// Initialize scanner
		Scanner scan = new Scanner(System.in);

		do {
			try {
				System.out.println("Please enter the number of players (2 or 4 only): ");
				numOfPlayers = scan.nextInt();
				if ((numOfPlayers == 2) || (numOfPlayers == 4)) {
					continueLoop = false;
				} else {
					System.out.println("2 or 4 players only. Try again.");

				}
			} catch (InputMismatchException e) {
				System.out.println("Try again. Please enter a valid number.");
				scan.nextLine();
			}
		} while (continueLoop);

		continueLoop = true; // set default value for next try catch

		do {
			try {
				System.out.println("Please enter the number of times the deck will be shuffled: ");
				numOfShuffles = scan.nextInt();
				if (numOfShuffles < 1) {
					System.out.println("Shuffle the deck at least once!");
				} else {
					continueLoop = false;
				}
			} catch (InputMismatchException e) {
				System.out.println("Please enter a number.");
				scan.nextLine();
			}
		} while (continueLoop);

		scan.close();

		// Creates a deck using Card Class and ENUMS
		ArrayList<Card> deck = new ArrayList<Card>();
		for (Suit suit : Suit.values()) {
			for (Rank rank : Rank.values()) {
				Card card = new Card(rank.getValue(), rank.printRank(), suit.getValue(), suit.printSuit());
				deck.add(card);
			}

		}
		System.out.println("Initial deck:");
		for (Card card : deck) {
			System.out.print(card.toString() + ","); // Shows initial deck
		}

		ArrayList<Card> shuffledDeck = Deck.perfectShuffle(numOfShuffles, deck); // Shuffling of deck
																					

		// Display shuffled deck
		System.out.println("\n\nShuffled deck:");
		for (Card card : shuffledDeck) {
			System.out.print(card.toString() + ",");
		}

		System.out.println('\n');

		// Distribute cards to players
		List<Player> listPlayer = new ArrayList<>();

		for (int i = 0; i < numOfPlayers; i++) {
			int k = i + 1;
			listPlayer.add(new Player("Player " + k + ": "));
		}

		// deal Cards
		GameMethods.dealCards(numOfPlayers, listPlayer, shuffledDeck);

		// Start the game
		int round = 1;
		while (listPlayer.size() > 1) {
			System.out.println("\nround : " + round);
			GameMethods.startGame(listPlayer, numOfPlayers);
			System.out.println("**********************************************");
			round++;
		}
		// If player size = 1 game ends.
		System.out.println("Only 1 player left. The game ends.");
		System.out.println("\nThe winner is " + listPlayer.get(0).getPlayerName() + ". Total Round : " + (round - 1));
		for (Player player : listPlayer) {
			System.out.println("Winning Deck : " + player.getHands());
		}
	}

}
