package com.svi.WarCard.models;

import java.util.ArrayList;
import java.util.List;

public class Deck  {

	//Shuffles the deck of cards
	public static ArrayList<Card> perfectShuffle(int numberOfShuffles, List<Card> deck){
		ArrayList<Card> shuffledDeck = new ArrayList<Card>();
		for (int i=0; i < numberOfShuffles; i++) {
			List<Card> tempDeck = new ArrayList<Card>();
			if (!shuffledDeck.isEmpty()) {
				tempDeck = shuffledDeck;
			} else {
				tempDeck = deck;
			}

			shuffledDeck = new ArrayList<Card>();
			for (int j=0; j < 26; j++) {
				int k = j + 26;
				shuffledDeck.add(tempDeck.get(j));
				shuffledDeck.add(tempDeck.get(k));
			}
		}

		return shuffledDeck;
	}



}