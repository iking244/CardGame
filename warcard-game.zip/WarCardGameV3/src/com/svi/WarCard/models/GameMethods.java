package com.svi.WarCard.models;

import java.util.ArrayList;
import java.util.*;

public class GameMethods {
	public static void dealCards(int numOfPlayers, List<Player> listPlayer, ArrayList<Card> deck) {

		do {
			for (int i = 0; i < numOfPlayers; i++) {
				listPlayer.get(i).getHands().add(deck.get(0));
				deck.remove(0);
			}
		} while (!deck.isEmpty());

		System.out.println("Player Hands:  ");
		for (Player player : listPlayer) {
			Collections.reverse(player.getHands());
			System.out.println(player.getPlayerName() + " : " + player.getHands());
		}
	}

	public static List<Card> getTopCards(List<Player> listPlayer) {
		List<Card> cardBattleList = new ArrayList<Card>();
		for (Player player : listPlayer) {
			cardBattleList.add(player.getHands().get(0));
			player.getHands().remove(0);
		}
		return cardBattleList;
	}

	public static void startGame(List<Player> listPlayer, int numOfPlayers) {
		List<Card> cardBattleList = new ArrayList<Card>();
		System.out.println("***********************************");
		for (Player player : listPlayer) {
			System.out.println(player.getPlayerName() + ": " + player.getHands());
		}
		cardBattleList = (ArrayList<Card>) GameMethods.getTopCards(listPlayer);
		System.out.println("Table's Cards: " + cardBattleList);
		Card topCard = Collections.max(cardBattleList, Comparator.comparing(k -> k.getCardValue()));
		int tempIndex = cardBattleList.indexOf(topCard);
		Collections.rotate(cardBattleList, cardBattleList.size() - cardBattleList.indexOf(topCard));
		listPlayer.get(tempIndex).getHands().addAll(cardBattleList);
		System.out.println("The winning card is : " + topCard);
		cardBattleList.clear();
		listPlayer.removeIf(player -> player.getHands().isEmpty());
	}
}

