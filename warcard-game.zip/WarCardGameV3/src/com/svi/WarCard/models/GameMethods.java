package com.svi.WarCard.models;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class GameMethods {

	public static ArrayList<Card> generateDeck() throws IOException{

		ArrayList<Card> deck = new ArrayList<>();
		File path  = new File ("input.txt"); // File path of the deck list.
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
		String[] fileContent = reader.readLine().split(",");
		{ 
			for(String someText : fileContent){
				String token[] = someText.split("-");
				Rank rank = getRank(token[1]); 
				Suit suit = getSuit(token[0]); 

				if (rank != null && suit != null) {
					Card card = new Card(rank.getValue(), rank.printRank(), suit.getValue(),
							suit.printSuit());
					deck.add(card);

				}

			}
			System.out.println("Initial Deck: ");
			System.out.println(deck);
			reader.close();

			return deck;
		}
	}
	//Shuffles the deck of cards
	public static ArrayList<Card> perfectShuffle(int numberOfShuffles, List<Card> deck){
		ArrayList<Card> shuffledDeck = new ArrayList<Card>();

		for (int i=0; i < numberOfShuffles; i++) {
			List<Card> tempDeck = new ArrayList<Card>();
			if (!shuffledDeck.isEmpty()) {
				tempDeck = shuffledDeck;
			} else {
				tempDeck = deck;
			}

			shuffledDeck = new ArrayList<Card>();
			for (int j=0; j < 26; j++) {
				int k = j + 26;
				shuffledDeck.add(tempDeck.get(j));
				shuffledDeck.add(tempDeck.get(k));
			}
		}


		return shuffledDeck;
	}
	public static void dealCards(int numOfPlayers, List<Player> listPlayer, ArrayList<Card> deck) {

		while(!deck.isEmpty())
			for (int i = 0; i < numOfPlayers; i++) {
				listPlayer.get(i).getHands().add(deck.get(0));
				deck.remove(0);
				if (deck.isEmpty()){
					break;
				}

			}
		System.out.println("Player Hands:  ");
		for (Player player : listPlayer) {
			Collections.reverse(player.getHands());
			System.out.println(player.getPlayerName() + " : " + player.getHands());
		}
	}


	public static List<Card> getTopCards(List<Player> listPlayer) {
		List<Card> cardBattleList = new ArrayList<Card>();
		for (Player player : listPlayer) {
			cardBattleList.add(player.getHands().get(0));
			player.getHands().remove(0);
		}
		return cardBattleList;
	}

	public static void startGame(List<Player> listPlayer, int numOfPlayers) {
		List<Card> cardBattleList = new ArrayList<Card>();
		System.out.println("***********************************");
		for (Player player : listPlayer) {
			System.out.println(player.getPlayerName() + ": " + player.getHands());
		}
		cardBattleList = (ArrayList<Card>) GameMethods.getTopCards(listPlayer);
		System.out.println("Table's Cards: " + cardBattleList);
		Card topCard = Collections.max(cardBattleList, Comparator.comparing(k -> k.getCardValue()));
		int tempIndex = cardBattleList.indexOf(topCard);
		Collections.rotate(cardBattleList, cardBattleList.size() - cardBattleList.indexOf(topCard));
		listPlayer.get(tempIndex).getHands().addAll(cardBattleList);
		System.out.println("The winning card is : " + topCard);
		cardBattleList.clear();
		listPlayer.removeIf(player -> player.getHands().isEmpty());
	}
	public static Suit getSuit(String suitCode) {
		for (Suit suit : Suit.values()) {
			if (suit.printSuit().trim().equals(suitCode)) {
				return suit;
			}
		}

		return null;
	}

	public static Rank getRank(String rankCode) {
		for (Rank rank : Rank.values()) {
			if (rank.printRank().trim().equals(rankCode)) {
				return rank;
			}
		}

		return null;
	}

}

