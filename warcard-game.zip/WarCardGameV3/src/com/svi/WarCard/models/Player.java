package com.svi.WarCard.models;

import java.util.ArrayList;
import java.util.List;

public class Player {

	private List<Card> hands;
	private String playerName;

	public Player(String name) {
		this.playerName = name;
		hands = new ArrayList<Card>();

	}

	public String getPlayerName() {
		return playerName;
	}

	public List<Card> getHands() {
		return hands;
	}

	public static List<Player> addPlayer(int numOfPlayers){
		// Distribute cards to players
		List<Player> listPlayer = new ArrayList<>();

		for (int i = 0; i < numOfPlayers; i++) {
			int k = i + 1;
			listPlayer.add(new Player("Player " + k + ":"));
		}
		return listPlayer;

	}
}
