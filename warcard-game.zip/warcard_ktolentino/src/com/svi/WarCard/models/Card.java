package com.svi.WarCard.models;


public class Card {

	private int cardValue; // RANK-SUIT 
	private int rankValue; // 13-1
	private String suitCode; // D, H, S, C
	private String rankCode;
	private int suitValue; //4-1, Diamonds highest

	public Card(int rankValue, String rankCode, int suitValue, String suitCode) {

		setCardValue(rankValue + suitValue);
		setSuitCode(suitCode);
		setRankCode(rankCode);
		setSuitValue(suitValue);
		setRankValue(rankValue);
	}

	public int getCardValue() {
		return cardValue;
	}

	public void setCardValue(int i) {
		this.cardValue = i;
	}

	public int getRankValue() {
		return rankValue;
	}

	public void setRankValue(int rankValue) {
		this.rankValue = rankValue;
	}

	public int getSuitValue() {
		return suitValue;
	}

	public void setSuitValue(int suitValue) {
		this.suitValue = suitValue;
	}
	public String getSuitCode() {
		return suitCode;
	}

	public void setSuitCode(String suitCode) {
		this.suitCode = suitCode;
	}


	public String getRankCode() {
		return rankCode;
	}

	public void setRankCode(String suitCode) {
		this.rankCode = suitCode;
	}

	public String toString() {
		return ("|" + suitCode +"-"+ rankCode +"|");
	}





}
