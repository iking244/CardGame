package com.svi.WarCard.models;

public enum Rank {
	ACE(14,"A"),KING(13,"K"),QUEEN(12,"Q"),JACK(11,"J"), TEN(10,"10"),NINE(9,"9"),EIGHT(8,"8"),SEVEN(7,"7"),
	SIX(6,"6"),FIVE(5,"5"),FOUR(4,"4"),THREE(3,"3"),DEUCE(2,"2");


	//private Field
	private final int rankValue;
	private final String rankCode;



	//Constructor
	private Rank (int rankValue, String rankCode){
		this.rankValue = rankValue *4;
		this.rankCode = rankCode;	
	}

	//public Method
	public int getValue() {
		return rankValue;
	}
	public String printRank(){
		return rankCode;
	}
	
	public String toString(){
		return rankCode;
	}
	
}
